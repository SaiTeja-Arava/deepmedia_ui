import proxy from "express-http-proxy";
import request from "request";
import express from "express";

const app = express();

const serverPort = process.env.PORT || 8785

app.use((req, res, next) => {
  const fullUrl = `${req.protocol}://${req.get("host")}${req.originalUrl}`;
  console.log(`Full URL: ${fullUrl} , --  `, req.url, req.query, req.path);

  let home = process.env.SITE_ID;
  if (req.url == `/${home}`) {
    res.redirect(fullUrl + `/${home}`);
  }

  if (req.url == `/${home}/`) {
    res.redirect(fullUrl + home);
  }

  if (req.query["x"]) {
    let url = `${req.protocol}://${req.get("host")}/${home}/${home}/config`;

    res.redirect(url);
  }

  next();
});

app.use(
  proxy(`http://localhost:${serverPort}`, {
    proxyReqPathResolver: (req) => {
      return req.url;
    },
  })
);

const port = process.env.PROXY_PORT || 3001

app.listen(port, () => {
  request(`http://localhost:${serverPort}`, function (err, res, body) {
    console.log(`---------UI PROXY STARTED on ${port}---------`)
    if (err === null) {
      console.log("UI server is reachable from proxy server");
    } else {
      console.log("UI server is not reachable from proxy server");
    }
  });
});