import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const buildDir = 'build';
const baseUrl = process.env.SITE_ID || '';

function updateFile(filePath) {
	const content = fs.readFileSync(filePath, 'utf8');
	const regex = /k=e=u=s/g;

	const updatedContent = content.replace(regex, baseUrl);

	fs.writeFileSync(filePath, updatedContent);
}

function walk(dir) {
	const files = fs.readdirSync(dir);
	files.forEach((file) => {
		let filePath = path.join(dir, file);
		const stat = fs.statSync(filePath);

		if (stat.isDirectory()) {
			if (file === 'k=e=u=s') {
				const newDirPath = path.join(dir, baseUrl);
				fs.renameSync(filePath, newDirPath);
				filePath = newDirPath;
				console.log(`Directory renamed from "k=e=u=s" to "${baseUrl}"`);
			}
			console.log(`Checking ${filePath}`);
			walk(filePath);
		} else if (file.endsWith('.html') || file.includes('.js') || file.endsWith('.css')) {
			updateFile(filePath);
		}
	});
}

if (baseUrl) {
	walk(buildDir);
	console.log(`Base URL updated to: ${baseUrl}`);
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

const start = async () => {
	const { handler } = await import('./build/handler.js');

	// Serve static files from the 'static' directory
	app.use(express.static(path.join(__dirname, 'static')));

	// SvelteKit handler
	app.use(handler);

	const port = process.env.PORT || 8785;
	app.listen(port, () => {
		console.log(`UI Server running on port ${port}`);
	});
};

start();
