import { $, argv } from 'zx';

const FRPC_PATH = '/usr/local/bin/frpc';

$.verbose = true;

async function delay(time) {
    return new Promise((res) => setTimeout(res, time));
}

async function checkFrpcInstalled() {
    try {
        await $`command -v ${FRPC_PATH}`;
        return true;
    } catch {
        return false;
    }
}

async function installFrpc() {
    console.log('frpc is not installed. Installing frpc...');

    const version = process.env.FRPC_VERSION || '0.60.0';
    await $`wget -O frpc.tar.gz https://github.com/fatedier/frp/releases/latest/download/frp_${version}_linux_amd64.tar.gz`;
    await $`tar -zxvf frpc.tar.gz`;
    await $`mv frp_${version}_linux_amd64/frpc ${FRPC_PATH}`;
    await $`chmod +x ${FRPC_PATH}`;
    await $`rm frpc.tar.gz`;
    console.log('frpc installed successfully.');
}

async function ensureFrpcInstalled() {
    if (!(await checkFrpcInstalled())) {
        await installFrpc();
    } else {
        console.log('frpc is already installed.');
    }
}

async function startProxy() {
    await $`node ./proxy.js`;
}

async function startServer() {
    await $`node ./server.js`;
}

async function startFrpc() {
    await $`frpc -c ./frpc.toml`;
}

async function main() {
	$`echo HELLO STARTING SERVER`
    await ensureFrpcInstalled();
    startFrpc();
    await delay(1000);
    startServer();
    await delay(100);
    startProxy();
}

main().catch(console.error);