#!/bin/sh

# apk update
# apk add --no-cache wget
# apk add --no-cache tar

# wget --version

cd /app/server

echo "Current directory: $(pwd)"

echo "Installing npm dependencies..."
npm install

npm install -g zx

echo "Starting ui..."
zx start.mjs

docker run -d  --restart always -p 7400:7400   -v $(pwd)/server:/app/server   -e FRP_SERVER_ADDR=heimdall.keus.in   -e FRP_SERVER_PORT=8281   -e SITE_ID=Keus-199786d6-cf1f-47a7-87d9-af7f2a3ab9b0   --name deepmedia-ui-server   --user "$(id -u):$(id -g)"   node:alpine  sh -c "chmod +x /app/server/start.sh && /app/server/start.sh"

# podman run -d  --restart always -p 7400:7400   -v $(pwd)/server:/app/server   -e FRP_SERVER_ADDR=heimdall.keus.in   -e FRP_SERVER_PORT=8281   -e SITE_ID=Keus-199786d6-cf1f-47a7-87d9-af7f2a3ab9b0   --name deepmedia-ui-server   --user "$(id -u):$(id -g)"   node:20.11.1   sh -c "chmod +x /app/server/start.sh && /app/server/start.sh"